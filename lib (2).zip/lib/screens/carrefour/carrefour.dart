import 'package:flutter/material.dart';

class Carefour extends StatelessWidget {
  const Carefour({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Carefour - 0306"),
      ),
      body: Container(
        child: const Column(
          children: [],
        ),
      ),
    );
  }
}
