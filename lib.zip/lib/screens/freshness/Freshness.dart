import 'package:cstore/Model/database_model/trans_freshness_model.dart';
import 'package:cstore/screens/freshness/ViewFreshness.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Database/db_helper.dart';
import '../../Model/database_model/category_model.dart';
import '../../Model/database_model/client_model.dart';
import '../../Model/database_model/rtv_show_model.dart';
import '../../Model/database_model/show_freshness_list_model.dart';
import '../../Model/database_model/sys_brand_model.dart';
import '../utils/app_constants.dart';
import '../utils/appcolor.dart';
import '../utils/toast/toast.dart';
import '../widget/app_bar_widgets.dart';
import 'freshnesscard.dart';

class Freshness_Screen extends StatefulWidget {
  static const routeName = "/FreshnessListScreen";

  const Freshness_Screen({super.key});

  @override
  State<Freshness_Screen> createState() => _Freshness_ScreenState();
}

class _Freshness_ScreenState extends State<Freshness_Screen> {
  List<FreshnessListShowModel> transData = [];
  bool isLoading = false;
  String workingId = "";
  String clientId = "";
  String storeName = '';
  int totalPieces = 0;
  bool isCategoryLoading = false;
  bool isSubCategoryLoading = false;
  bool isBrandLoading = false;
  String month = "";
  int year = 0;
  String pieces = "";
  final GlobalKey<FormFieldState> clientKey = GlobalKey<FormFieldState>();
  final GlobalKey<FormFieldState> categoryKey = GlobalKey<FormFieldState>();
  final GlobalKey<FormFieldState> subCategoryKey = GlobalKey<FormFieldState>();
  final GlobalKey<FormFieldState> brandKey = GlobalKey<FormFieldState>();
  List<ClientModel> clientData = [];
  List<CategoryModel> categoryData = [
    CategoryModel(client: -1, id: -1, en_name: '', ar_name: '')
  ];
  List<CategoryModel> subCategoryData = [
    CategoryModel(client: -1, id: -1, en_name: '', ar_name: '')
  ];
  List<SYS_BrandModel> brandData = [
    SYS_BrandModel(client: -1, id: -1, en_name: '', ar_name: '')
  ];
  int selectedClientId = -1;
  int selectedCategoryId = -1;
  int selectedSubCategoryId = -1;
  int selectedBrandId = -1;

  late ClientModel initialClientItem;
  late CategoryModel initialCategoryItem;
  late CategoryModel initialSubCategoryItem;
  late SYS_BrandModel initialBrandItem;

  void getClientData() async {
    setState(() {
      isLoading = true;
    });
    await DatabaseHelper.getVisitClientList(clientId).then((value) {
      setState(() {
        isLoading = false;
      });
      clientData = value;
      clientData.insert(
          0, ClientModel(client_id: -1, client_name: "Select Client"));
      categoryData.insert(
          0,
          CategoryModel(
              en_name: "Select Category",
              ar_name: "Select Category",
              id: -1,
              client: -1));
      subCategoryData.insert(
          0,
          CategoryModel(
              en_name: "Select Sub Category",
              ar_name: "Select Sub Category",
              id: -1,
              client: -1));
      brandData.insert(
          0,
          SYS_BrandModel(
              en_name: "Select Brand",
              ar_name: "Select Brand",
              id: -1,
              client: -1));

      initialClientItem = clientData[0];
      initialCategoryItem = categoryData[0];
      initialSubCategoryItem = subCategoryData[0];
      initialBrandItem = brandData[0];
    });
    print(clientData[0].client_name);
  }

  void getCategoryData(int clientId, StateSetter menuState) async {
    categoryKey.currentState!.reset();
    selectedCategoryId = -1;
    menuState(() {
      isCategoryLoading = true;
    });

    await DatabaseHelper.getCategoryList(selectedClientId).then((value) {
      categoryData = value;
      categoryData.insert(
          0,
          CategoryModel(
              en_name: "Select Category",
              ar_name: "Select Category",
              id: -1,
              client: -1));

      initialCategoryItem = categoryData[0];
      menuState(() {
        isCategoryLoading = false;
      });
    });
    print(categoryData[0].en_name);
  }

  void getSubCategoryData(int clientId, StateSetter menuState) async {
    subCategoryKey.currentState!.reset();
    selectedSubCategoryId = -1;
    menuState(() {
      isSubCategoryLoading = true;
    });

    await DatabaseHelper.getSubCategoryList(selectedClientId).then((value) {
      subCategoryData = value;
      subCategoryData.insert(
          0,
          CategoryModel(
              en_name: "Select Sub Category",
              ar_name: "Select Sub Category",
              id: -1,
              client: -1));

      initialSubCategoryItem = subCategoryData[0];
      // print(jsonEncode(subCategoryData));
      menuState(() {
        isSubCategoryLoading = false;
      });
    });
  }

  void getBrandData(int clientId, StateSetter menuState) async {
    brandKey.currentState!.reset();
    selectedBrandId = -1;
    menuState(() {
      isBrandLoading = true;
    });

    await DatabaseHelper.getBrandList(selectedClientId).then((value) {
      brandData = value;

      brandData.insert(
          0,
          SYS_BrandModel(
              en_name: "Select Brand",
              ar_name: "Select Brand",
              id: -1,
              client: -1));

      initialBrandItem = brandData[0];
      menuState(() {
        isBrandLoading = false;
      });
    });
  }

  @override
  void initState() {
    getUserData();
    getStoreDetails();
    super.initState();
  }

  getStoreDetails() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    setState(() {
      workingId = sharedPreferences.getString(AppConstants.workingId)!;
      storeName = sharedPreferences.getString(AppConstants.storeEnNAme)!;
      clientId = sharedPreferences.getString(AppConstants.clientId)!;
    });
    getClientData();
    getFreshnessListOne();
  }

  Future<void> getFreshnessListOne() async {
    await DatabaseHelper.getDataListFreshness(
            workingId,
            selectedClientId.toString(),
            selectedBrandId.toString(),
            selectedCategoryId.toString(),
            selectedSubCategoryId.toString())
        .then((value) async {
      transData = value;
      setState(() {});
    });
  }

  getUserData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    storeName = sharedPreferences.getString(AppConstants.storeEnNAme)!;
    setState(() {});
    print(storeName);
  }

  void InsertTransFreshness(month, year, pieces, skuId) async {
    var now = DateTime.timestamp();
    if (month == "" || year == 0 || pieces == "") {
      ToastMessage.errorMessage(context, "Please fill the form");
      return;
    }
    setState(() {
      isLoading = false;
    });
    await DatabaseHelper.insertOrUpdateTransFreshness(month, clientId, year, skuId, workingId, int.parse(pieces))
        .then((_) {
      ToastMessage.succesMessage(context,"Data store successfully");
      year = 0;
      month = 0;
      pieces = 0;
      getFreshnessListOne();
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: generalAppBar(context, storeName, "Freshness", () {
        Navigator.of(context).pop();
      }, () {
        print("filter Click");
      }, true, false, false),
      body: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Card(
                elevation: 2,
                child: Container(
                  height: screenHeight / 7,
                  width: screenWidth / 3.3,
                  decoration: BoxDecoration(
                      color: const Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(width: 1, color: const Color(0xFFFFFFFF))),
                  child: Column(
                    children: [
                      Container(
                          margin: const EdgeInsets.only(top: 5),
                          child: const Text("Total Skus",
                              style: TextStyle(
                                  color: Color.fromRGBO(0, 78, 180, 1),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400))),
                      SizedBox(height: screenHeight / 100),
                      CircularPercentIndicator(
                        radius: 23.0,
                        lineWidth: 5.0,
                        animation: true,
                        percent: 0.6,
                        center: const Text("08",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15.0,
                                color: Color(0xFF5B954B))),
                        circularStrokeCap: CircularStrokeCap.round,
                        progressColor: Color(0xFF5B954B),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                elevation: 2,
                child: Container(
                  height: screenHeight / 7,
                  width: screenWidth / 3.3,
                  decoration: BoxDecoration(
                      color: const Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(width: 1, color: Color(0xFF00000026))),
                  child: Column(
                    children: [
                      Container(
                          margin: EdgeInsets.only(top: 5),
                          child: const Text("Total Value",
                              style: TextStyle(
                                  color: Color.fromRGBO(0, 78, 180, 1),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400))),
                      SizedBox(height: screenHeight / 100),
                      CircularPercentIndicator(
                        radius: 23.0,
                        lineWidth: 5.0,
                        animation: true,
                        percent: 0.4,
                        center: const Text("03",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15.0,
                                color: Color(0xFF5B954B))),
                        circularStrokeCap: CircularStrokeCap.round,
                        progressColor: const Color(0xFF5B954B),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                  elevation: 2,
                  child: Container(
                    height: screenHeight / 7,
                    width: screenWidth / 3.4,
                    decoration: BoxDecoration(
                        color: const Color(0xFFFFFFFF),
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(width: 1, color: Color(0xFF00000026))),
                    child: Column(
                      children: [
                        Container(
                            margin: const EdgeInsets.only(top: 5),
                            child: const Text(
                              "Scan Now",
                              style: TextStyle(
                                  color: Color.fromRGBO(0, 78, 180, 1),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400),
                            )),
                        SizedBox(height: screenHeight / 50),
                        const Icon(Icons.document_scanner_outlined, size: 40),
                      ],
                    ),
                  )),
            ],
          ),
          Expanded(
            child: ListView.builder(
                shrinkWrap: true,
                itemCount: transData.length,
                itemBuilder: (ctx, i) {
                  return FreshnessListCard(
                    image:
                        "https://storage.googleapis.com/panda-static/sku_pictures/${transData[i].img_name}",
                    proName: transData[i].pro_en_name,
                    catName: transData[i].cat_en_name,
                    rsp: transData[i].rsp,
                    freshnessDate: (String pieces, String month, int year) {
                      InsertTransFreshness(
                          month, year, pieces, transData[i].pro_id);
                      print("fun is last $month,$year,$pieces");
                      setState(() {});
                    },
                    freshnessTaken: transData[i].freshness_taken,
                    brandName: transData[i].brand_en_name,
                  );
                }),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color.fromRGBO(0, 77, 145, 1),
              minimumSize: Size(MediaQuery.of(context).size.width/1.1, 45),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () async {

              Navigator.of(context)
                  .pushNamed(ViewFreshness_Screen.routeName);
            },
            child: const Text(
              "View Freshness",style: TextStyle(color: MyColors.whiteColor),
            ),
          )
        ]),
      ),
    );
  }
}
