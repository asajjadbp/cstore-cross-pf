import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Database/db_helper.dart';
import '../../Model/database_model/trans_freshness_model.dart';
import '../utils/app_constants.dart';
import '../widget/app_bar_widgets.dart';
import 'ViewFreshnesscard.dart';

class ViewFreshness_Screen extends StatefulWidget {
  static const routeName = "/FreshnessViewScreen";

  const ViewFreshness_Screen({super.key});

  @override
  State<ViewFreshness_Screen> createState() => _ViewFreshness_ScreenState();
}

class _ViewFreshness_ScreenState extends State<ViewFreshness_Screen> {
  String storeName = "";
  List<TransFreshnessModel> transData = [];
  bool isLoading = false;
  String workingId = "";
  String clientId = '';

  @override
  void initState() {
    getUserData();
    super.initState();
  }

  getUserData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    storeName = sharedPreferences.getString(AppConstants.storeEnNAme)!;
    workingId = sharedPreferences.getString(AppConstants.workingId)!;
    getTransFreshnessOne();
    setState(() {});
  }

  Future<void> getTransFreshnessOne() async {
    await DatabaseHelper.getTransFreshnessDataList(workingId)
        .then((value) async {
      transData = value.cast<TransFreshnessModel>();
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: generalAppBar(context, storeName, "View Freshness", () {
        Navigator.of(context).pop();
      }, () {
        print("filter Click");
      }, true, false, false),
      body: ListView.builder(
          shrinkWrap: true,
          itemCount: transData.length,
          itemBuilder: (ctx, i) {
            return  Padding(
              padding: const EdgeInsets.all(10),
              child: ExpiryCard(
                  sku_id: transData[i].sku_id,
                  year:  transData[i].year,
                  jan:  transData[i].jan,
                  feb:  transData[i].feb,
                  mar:  transData[i].mar,
                  apr:  transData[i].apr,
                  may:  transData[i].may,
                  jun:  transData[i].jun,
                  jul:  transData[i].jul,
                  aug:  transData[i].aug,
                  sep:  transData[i].sep,
                  oct:  transData[i].oct,
                  nov:  transData[i].nov,
                  dec:  transData[i].dec,
                  sku_en_name:  transData[i].sku_en_name,
                  sku_ar_name:  transData[i].sku_ar_name,
                   imageName:  "https://storage.googleapis.com/panda-static/sku_pictures/${transData[i].imgName}",),
            );
          }),
    );
  }
}
