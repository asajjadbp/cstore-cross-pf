import 'package:cstore/screens/promoplane/planogramdropbutton.dart';
import 'package:cstore/screens/utils/app_constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../widget/app_bar_widgets.dart';
import 'Promoplancard.dart';

class PromoPlan_scrren extends StatefulWidget {
  static const routeName = "/promoPlane";

  const PromoPlan_scrren({super.key});

  @override
  State<PromoPlan_scrren> createState() => _PromoPlan_scrrenState();
}

class _PromoPlan_scrrenState extends State<PromoPlan_scrren> {

  String storeName = "";

  @override
  void initState() {
    // TODO: implement initState

    getUserData();
    super.initState();
  }

  getUserData()  async {

    SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();

    storeName  = sharedPreferences.getString(AppConstants.storeEnNAme)!;
    setState(() {

    });
    print(storeName);
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FD),
      appBar: generalAppBar(context, storeName, "Promotion", (){
        Navigator.of(context).pop();
      }, (){print("filter Click");}, true, false, false),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        child: ListView.builder(
            itemCount: 5,
            shrinkWrap: true,
            itemBuilder: (context, index) {
          return PromoPlanCard();
        }),
      )
    );
  }
}
