import 'dart:convert';

GetPromoPlanRequestModel getPromoPlanRequestModel(String str) =>
    GetPromoPlanRequestModel.fromJson(json.decode(str));

String getPromoPlanRequestModelToJson(GetPromoPlanRequestModel data) =>
    json.encode(data.toJson());

class GetPromoPlanRequestModel {
  String username;
  String storeId;
  String clientId;

  GetPromoPlanRequestModel({
    required this.username,
    required this.storeId,
    required this.clientId,
  });

  factory GetPromoPlanRequestModel.fromJson(Map<String, dynamic> json) =>
      GetPromoPlanRequestModel(
        username: json["username"],
        storeId: json['store_id'],
        clientId: json['client_id'],
      );

  Map<String, dynamic> toJson() => {
    "username": username,
    'store_id':storeId,
    'client_id':clientId
  };
}


PostPromoPlanRequestModel postPromoPlanRequestModel(String str) =>
    PostPromoPlanRequestModel.fromJson(json.decode(str));

String postPromoPlanRequestModelToJson(PostPromoPlanRequestModel data) =>
    json.encode(data.toJson());

class PostPromoPlanRequestModel {
  String username;
  String storeId;
  String workingId;
  String companyId;
  String promoId;
  String skuId;
  String deployed;
  String reason;
  String imageName;

  PostPromoPlanRequestModel({
    required this.username,
    required this.storeId,
    required this.workingId,
    required this.companyId,
    required this.promoId,
    required this.skuId,
    required this.deployed,
    required this.reason,
    required this.imageName
  });

  factory PostPromoPlanRequestModel.fromJson(Map<String, dynamic> json) =>
      PostPromoPlanRequestModel(
        username: json["username"],
        storeId: json['store_id'],
        workingId: json['working_id'],
        companyId: json["company_id"],
        promoId: json['promo_id'],
        skuId: json['sku_id'],
        deployed: json["deployed"],
        reason: json['reason'],
        imageName: json['image'],
      );

  Map<String, dynamic> toJson() => {
    "username": username,
    'store_id':storeId,
    'working_id':workingId,
    "company_id": companyId,
    'promo_id':promoId,
    'sku_id':skuId,
    "deployed": deployed,
    'reason':reason,
    'image':imageName
  };
}