
import 'package:cstore/screens/promoplane/widgets/promo_plan_card_row_item.dart';
import 'package:cstore/screens/utils/appcolor.dart';
import 'package:cstore/screens/widget/drop_downs.dart';
import 'package:flutter/material.dart';

class PromoPlanCard extends StatelessWidget {
  PromoPlanCard({super.key,});
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Container(
      decoration: const BoxDecoration(
          color: MyColors.background,),
      margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
         Card(
           elevation: 2,
           shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight:Radius.circular(20))),
           child: Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             mainAxisAlignment: MainAxisAlignment.center,
             children: [
               Container(
                 alignment: Alignment.center,
                 width: screenWidth,
                 padding:const EdgeInsets.symmetric(vertical: 10),
                  decoration:const BoxDecoration(
                      border: Border(top: BorderSide(color: MyColors.appMainColor,width: 3) ),
                      color: MyColors.whiteColor),
                 child: const Text("NIVEA ORIGINAL CREAM TIN 60ML",style: TextStyle(color: MyColors.appMainColor),),
               ),
               const PromoPlanCardRowItems(title: "Category",value: "Body Lotion",isWhiteBackGround: false,),
               const PromoPlanCardRowItems(title: "Brand",value: "Nivea",isWhiteBackGround: true,),
               const PromoPlanCardRowItems(title: "From",value: "24/07/2024",isWhiteBackGround: false,),
               const PromoPlanCardRowItems(title: "To",value: "24/07/2024",isWhiteBackGround: true,),
               const PromoPlanCardRowItems(title: "OSD Type",value: "Gondola",isWhiteBackGround: false,),
               const PromoPlanCardRowItems(title: "Pieces",value: "22",isWhiteBackGround: true,),
              const PromoPlanCardRowItems(title: "Promo Scope",value: "National",isWhiteBackGround: false,),
               const PromoPlanCardRowItems(title: "Promo Price",value: "20 SAR",isWhiteBackGround: true,),
               const PromoPlanCardRowItems(title: "Left Over Action",value: "Keep As It is",isWhiteBackGround: false,),
             ],
           ),
         ),

          Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Status"),

                  AdherenceDropDown(hintText: "Select Status",initialValue: 'Implemented', unitData: const ['Implemented','Not Implemented'], onChange: (value){print(value);}),
                ],
              )),

          Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Reason"),

                  AdherenceDropDown(hintText: "Select Reason",initialValue: 'Out Of Stock', unitData: const ['Out Of Stock','Damage','Expired'], onChange: (value){print(value);}),
                ],
              )),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          margin: const EdgeInsets.only(top: 8, left: 10, bottom: 5),
                          child: const Text(
                            "Model",
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                          )),
                      InkWell(
                        onTap: (){

                        },
                        child: Card(
                          child: Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width/2.2,
                            height: 155,
                            child: Card(
                                child: Image.asset("assets/icons/camera_icon.png"),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    children: [
                      Container(
                          margin: const EdgeInsets.only(top: 8, right: 115, bottom: 5),
                          child: const Text(
                            "Actual",
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                          )),
                      Container(
                        width: MediaQuery.of(context).size.width/2.2,
                        height: 160,
                        child: InkWell(
                          onTap: () {

                          },
                          child: Card(
                            color: Colors.white,
                            elevation: 1,
                            child: Image.asset("assets/icons/gallery_icon.png"),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          InkWell(
            onTap: () {
              // Navigator.push(context, MaterialPageRoute(builder: (context) => oneplusone_SCreen(),));
            },
            child: Container(
              alignment: Alignment.center,
                height: screenHeight / 18,
                width: screenWidth,
                margin:const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                decoration: BoxDecoration(
                    color: const Color.fromRGBO(26, 91, 140, 1),
                    borderRadius: BorderRadius.circular(5)),
                child: const Text(
                  "Save",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),
                )),
          ),
        ],
      ),
    );
  }
}
