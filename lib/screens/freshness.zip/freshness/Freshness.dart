import 'package:cstore/screens/freshness/ViewFreshness.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/app_constants.dart';
import '../widget/app_bar_widgets.dart';
import 'freshnesscard.dart';

class Freshness_Screen extends StatefulWidget {
  static const routeName = "/FreshnessListScreen";
  const Freshness_Screen({super.key});

  @override
  State<Freshness_Screen> createState() => _Freshness_ScreenState();
}

class _Freshness_ScreenState extends State<Freshness_Screen> {


  String storeName = "";

  @override
  void initState() {
    // TODO: implement initState

    getUserData();
    super.initState();
  }

  getUserData()  async {

    SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();

    storeName  = sharedPreferences.getString(AppConstants.storeEnNAme)!;
    setState(() {

    });
    print(storeName);
  }


  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
appBar: generalAppBar(context, storeName, "Freshness", (){
  Navigator.of(context).pop();
}, (){print("filter Click");}, true, false, false),
body: Padding(
 padding: const EdgeInsets.all(5),
  child: Column(children: [
        Row(
       mainAxisAlignment: MainAxisAlignment.spaceBetween,
       children: [
         Card(
           elevation: 2,
           child: Container(
             height: screenHeight/7,
             width: screenWidth/3.3,
             decoration: BoxDecoration(
                 color: Color(0xFFFFFFFF),
                 borderRadius: BorderRadius.circular(10),
                 border: Border.all(width: 1,color: Color(0xFF00000026))
             ),
             child: Column(
               children: [
                 Container(
                     margin: const EdgeInsets.only(top: 5),
                     child: const Text("Total Skus",style: TextStyle(color: Color.fromRGBO(0, 78, 180, 1),fontSize: 15,fontWeight: FontWeight.w400))),
                 SizedBox(height: screenHeight/100),
                 CircularPercentIndicator( radius: 23.0,
                   lineWidth: 5.0,
                   animation: true,
                   percent: 0.6,
                   center: const Text(
                       "08",
                       style:  TextStyle(
                           fontWeight: FontWeight.bold, fontSize: 15.0,
                           color: Color(0xFF5B954B))),
                   circularStrokeCap: CircularStrokeCap.round,
                   progressColor: Color(0xFF5B954B),
                 ),

               ],
             ),
           ),
         ),
           Card(
         elevation: 2,
             child: Container(
                height: screenHeight/7,
            width: screenWidth/3.3,
            decoration: BoxDecoration(
           color: const Color(0xFFFFFFFF),
           borderRadius: BorderRadius.circular(10),
           border: Border.all(width: 1,color: Color(0xFF00000026))
         ),
               child: Column(
                 children: [
                   Container(
                     margin: EdgeInsets.only(top: 5),
                     child: const Text("Total Value",style: TextStyle(color: Color.fromRGBO(0, 78, 180, 1),fontSize: 15,fontWeight: FontWeight.w400))),
                    SizedBox(height: screenHeight/100),
                     CircularPercentIndicator( radius: 23.0,
                                 lineWidth: 5.0,
                                 animation: true,
                                 
                                 percent: 0.4,
                                 center: const Text(
                                   "03",
                                   style:  TextStyle(
                                       fontWeight: FontWeight.bold, fontSize: 15.0,
                                       color: Color(0xFF5B954B))),
                                          circularStrokeCap: CircularStrokeCap.round,
                             progressColor: const Color(0xFF5B954B),
                                 ),
                   
                 ],
               ),
             ),
             ),
          Card(
                               
                elevation: 2,
                  child: Container(
                      height: screenHeight/7,
               width: screenWidth/3.4,
                           
                           decoration: BoxDecoration(
                       color: Color(0xFFFFFFFF),
                       borderRadius: BorderRadius.circular(10),
                       border: Border.all(width: 1,color: Color(0xFF00000026))
                           ),
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 5),
                          child: Text("Scan Now", style: TextStyle(color: Color.fromRGBO(0, 78, 180, 1),fontSize:15, fontWeight: FontWeight.w400),)),
                        SizedBox(height: screenHeight/50),
                        Icon(Icons.document_scanner_outlined,size:40),
                      ],
                    ),
                    
                  )
                  ),
       ],
       ),
       Expanded(
        child: ListView.builder(
          shrinkWrap: true,
              itemCount: 8,
              itemBuilder: (ctx, i) {
                return InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed(ViewFreshness_Screen.routeName);
                  },
                  child: FreshnessListCard(
                    image:"https://images-as.nivea.com/-/media/miscellaneous/media-center-items/b/e/4/229140-web_1010x1180_transparent_png.png",
                    proName: "Niva Cream 60ml",
                    catName: "Body Lotion",
                    rsp: "1",
                    pricingValues: (int regular, int promo) {
                      setState(() {
                      });
                    },
                    freshnessTaken:1,
                    brandName: "Niva Sun",
                  ),
                );
                     }
                     ),
      ),
  ]),
),
    );
  }
}


