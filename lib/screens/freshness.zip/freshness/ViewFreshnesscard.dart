
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
class ExpiryCard extends StatelessWidget {
  const ExpiryCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
        final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Stack(
      children: [
        Container(
            height: 180,

            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.4),
                  spreadRadius: 1,
                  blurRadius: 3,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            
            child: Column(
              children: [
              const Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  Text(
                    "Nivea Cream 60ml",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      flex: 1,
                      child: Container(
                        width: 90,
                        height: 80,
                        decoration: const BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                        child: Image.asset(
                          "assets/images/view_freshness.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    Flexible(
                        flex: 2,
                        child: SizedBox(
                            height: 130,
                            child: MasonryGridView.count(
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: 12,
                                crossAxisCount: 4,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10 ,
                                itemBuilder: (context, index) {
                                  return CardWidget(
                                    title: "jan",
                                    data: index % 2 == 0 ? index : null,
                                  );
                                }))),
                  ],
                ),
              ),

            ])),
      ],
    );
  }
}

class CardWidget extends StatelessWidget {
  final String title;
  final int? data;

  CardWidget({required this.title, this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 35,
      child: Stack(
        children: [
          Positioned(
            child: Container(
              height: 10.0,
              width: 100,
              decoration: BoxDecoration(
                  color: data != null ? Colors.red : Colors.green,
                  borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(4),
                      topRight: Radius.circular(4))),
            ),
          ),
          Positioned(
            top: 3,
            left: 0,
            right: 0,
            child: Container(
              height: 32,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 0.3,
                    blurRadius: 1,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Space for the top border
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 11.0,
                      fontWeight: FontWeight.w600,
                      color: Colors.red,
                    ),
                  ),
                  Text(
                    data != null ? data.toString() : '--',
                    style: const TextStyle(
                      fontSize: 11.0,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}