import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/app_constants.dart';
import '../widget/app_bar_widgets.dart';
import 'ViewFreshnesscard.dart';

class ViewFreshness_Screen extends StatefulWidget {
  static const routeName = "/FreshnessViewScreen";
  const ViewFreshness_Screen({super.key});

  @override
  State<ViewFreshness_Screen> createState() => _ViewFreshness_ScreenState();
}

class _ViewFreshness_ScreenState extends State<ViewFreshness_Screen> {

  String storeName = "";

  @override
  void initState() {
    // TODO: implement initState

    getUserData();
    super.initState();
  }

  getUserData()  async {

    SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();

    storeName  = sharedPreferences.getString(AppConstants.storeEnNAme)!;
    setState(() {

    });
    print(storeName);
  }


  @override
  Widget build(BuildContext context) {
     final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: generalAppBar(context, storeName, "View Freshness", (){
        Navigator.of(context).pop();
      }, (){print("filter Click");}, true, false, false),
body:

  ListView.builder(
   
  shrinkWrap: true,
      itemCount: 2,
      itemBuilder: (ctx, i) {
        return  const Padding(
          padding: EdgeInsets.all(10),
          child: ExpiryCard(),
        );}),
    );
  }
}

